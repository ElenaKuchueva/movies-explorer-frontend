// import React from "react";
// import "./Popup.css";
// import NavTab from "../NavTab/NavTab.js";
// import AccountButton from "../AccountButton/AccountButton.js";
// import closePopup from "../../images/close-popup.svg";

// function Popup() {
//   return (
//     <div className="popup-hidden">
//       <div className="popup">
//         <div className="popup__block">
//           <div className="popup__links">
//             <p className="popup__link">Главная</p>
//             <NavTab />
//           </div>
//           <AccountButton />
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Popup;
